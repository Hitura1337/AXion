#pragma once

// used: find pattern, call virtual function
#include "../../utilities/memory.h"

// used: vertor_t
#include "../datatypes/vector.h"
// used: color_t
#include "../datatypes/color.h"

class IDebugOverlayGameSystem
{
public:
	// @todo: reverse this
};