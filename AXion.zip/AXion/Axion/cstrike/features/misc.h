#pragma once
class CUserCmd;
class CCSPlayerController;
class C_CSPlayerPawn;
class QAngle_t;
class CCSGOInput;
namespace F::MISC
{
}